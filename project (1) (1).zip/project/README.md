# Proyecto ESP32 + DHT22 — Wokwi en VS Code

## 📁 Estructura (así debe quedar la carpeta abierta en VS Code)

```
project/
├── platformio.ini      <- config del entorno ESP32 y librerías
├── wokwi.toml           <- le dice a Wokwi dónde está el firmware compilado
├── diagram.json          <- el circuito (ESP32 + DHT22 + LED)
├── src/
│   └── main.cpp             <- el código del ESP32
└── dashboard/
    └── panel_iot.html    <- el dashboard (se abre aparte, en el navegador)
```

Todo lo que está en la raíz (`platformio.ini`, `wokwi.toml`, `diagram.json`)
y la carpeta `src/` es lo que PlatformIO/Wokwi necesitan para compilar y
simular. La carpeta `dashboard/` es independiente: no la toca PlatformIO,
es solo para que la tengas ordenada junto al resto del proyecto.

## ▶️ Cómo correrlo

1. Abrí esta carpeta completa en VS Code (Archivo > Abrir carpeta).
2. Compilá con el ícono de tilde (✔) de PlatformIO en la barra inferior,
   o `Ctrl+Alt+B`. La primera vez descarga las librerías DHT y PubSubClient.
3. Iniciá la simulación: `Ctrl+Shift+P` → escribí `Wokwi: Start Simulator`.
4. Esperá a ver en el monitor serie: `WiFi conectado` y luego líneas como
   `Publicado -> Temp: 24.30 C | Hum: 55.10 %`.
5. Con la simulación corriendo, abrí `dashboard/panel_iot.html` con doble
   clic (se abre en tu navegador normal). En unos segundos el indicador
   de conexión debería pasar a "Conectado al broker" y vas a empezar a
   ver los datos y poder tocar el interruptor del LED.

## 🔧 Si algo no anda

- **No compila / faltan librerías**: revisá que `platformio.ini` tenga
  bien escritas las 3 líneas de `lib_deps`. PlatformIO las descarga solo,
  pero necesita internet la primera vez.
- **La simulación no arranca**: fijate en la pestaña "Wokwi" de VS Code si
  tira algún error de licencia (tenés que haber pegado la clave gratuita).
- **El dashboard queda en "Conectando…"**: revisá que la simulación esté
  efectivamente corriendo (no solo compilada) y que tu red no bloquee el
  puerto 8081 (WebSocket seguro). Alternativa: cambiar en `panel_iot.html`
  la línea `MQTT_URL` a `"ws://test.mosquitto.org:8080/mqtt"`.
- **Los tópicos no coinciden**: si editás los nombres de tópico en
  `main.cpp`, tenés que cambiar exactamente los mismos en `panel_iot.html`
  (las constantes `TOPIC_TEMP`, `TOPIC_HUM`, `TOPIC_LED_CMD`,
  `TOPIC_LED_STATE`).
