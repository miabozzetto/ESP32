/*
  ============================================================
  Proyecto: Estación IoT con ESP32 + DHT22 (Wokwi en VS Code)
  ============================================================
  Qué hace este código:
    1) Lee temperatura y humedad del sensor DHT22.
    2) Publica esos datos por MQTT a un broker público, para que
       el dashboard (panel_iot.html) los reciba en tiempo real.
    3) Se suscribe a un tópico de control para encender/apagar
       un LED (actuador) según los comandos que envíe el dashboard.

  Con PlatformIO las librerías se definen en platformio.ini
  (lib_deps) y se descargan solas al compilar. No hace falta
  instalarlas manualmente.
  ============================================================
*/

#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ---------- 1. Configuración de pines ----------
#define DHTPIN 4        // GPIO4 -> pin de datos (SDA) del DHT22
#define DHTTYPE DHT22
#define LED_PIN 2       // GPIO2 -> LED actuador controlado desde el dashboard

DHT dht(DHTPIN, DHTTYPE);

// ---------- 2. Configuración WiFi (red simulada de Wokwi) ----------
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ---------- 3. Configuración del broker MQTT ----------
// Broker público de prueba. IMPORTANTE: estos tópicos deben ser
// IDÉNTICOS a los definidos en panel_iot.html
const char* mqtt_server = "test.mosquitto.org";
const int   mqtt_port   = 1883;

const char* topic_temp      = "iot/miproyecto123/dht22/temperatura";
const char* topic_hum       = "iot/miproyecto123/dht22/humedad";
const char* topic_led_cmd   = "iot/miproyecto123/actuador/led/set";
const char* topic_led_state = "iot/miproyecto123/actuador/led/estado";

WiFiClient espClient;
PubSubClient client(espClient);

unsigned long lastMsg = 0;
const long interval = 3000; // publicar lecturas cada 3 segundos

// ---------- 4. Conexión WiFi ----------
void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Conectando a WiFi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi conectado.");
  Serial.print("IP asignada: ");
  Serial.println(WiFi.localIP());
}

// ---------- 5. Callback: se ejecuta al llegar un mensaje MQTT ----------
void callback(char* topic, byte* payload, unsigned int length) {
  String mensaje;
  for (unsigned int i = 0; i < length; i++) {
    mensaje += (char)payload[i];
  }
  Serial.printf("Mensaje MQTT recibido [%s]: %s\n", topic, mensaje.c_str());

  if (String(topic) == topic_led_cmd) {
    if (mensaje == "ON") {
      digitalWrite(LED_PIN, HIGH);
      client.publish(topic_led_state, "ON");
    } else if (mensaje == "OFF") {
      digitalWrite(LED_PIN, LOW);
      client.publish(topic_led_state, "OFF");
    }
  }
}

// ---------- 6. Reconexión automática al broker MQTT ----------
void reconnect() {
  while (!client.connected()) {
    Serial.print("Conectando a broker MQTT...");
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println(" ¡conectado!");
      client.subscribe(topic_led_cmd);
      client.publish(topic_led_state, "OFF");
    } else {
      Serial.print(" falló, rc=");
      Serial.print(client.state());
      Serial.println(" -> reintentando en 2s");
      delay(2000);
    }
  }
}

// ---------- 7. setup() ----------
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  dht.begin();
  setup_wifi();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

// ---------- 8. loop() ----------
void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsg > interval) {
    lastMsg = now;

    float h = dht.readHumidity();
    float t = dht.readTemperature();

    if (isnan(h) || isnan(t)) {
      Serial.println("Error al leer el sensor DHT22 (revisar conexiones).");
      return;
    }

    char tempStr[8];
    char humStr[8];
    dtostrf(t, 4, 2, tempStr);
    dtostrf(h, 4, 2, humStr);

    client.publish(topic_temp, tempStr);
    client.publish(topic_hum, humStr);

    Serial.printf("Publicado -> Temp: %s C | Hum: %s %%\n", tempStr, humStr);
  }
}
